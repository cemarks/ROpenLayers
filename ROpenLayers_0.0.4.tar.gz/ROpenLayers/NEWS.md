# Coming soon

* Capability to control the direction of color scales.


# ROpenLayers 0.0.4

* Update Shiny example so that full code is written to App (make it stand alone)
* Update README.md to include ol_aes and scales.
* Update icon layer aesthetics to match scale names.
* Add PDF documentation to repository.
* Fix user_arcgis_basemap documentation
* Include package tar.gz

# ROpenLayers 0.0.3

* Updated README.md to include minimal, experimental Shiny example.
* Updated documentation `browseURL()` calls to include filenames only.

# RopenLayers 0.0.2

* Updated HTML tooltip class name to 'ol-tooltip' to prevent clashing when embedding in other pages.

# ROpenLayers 0.0.1

* Initial Commit